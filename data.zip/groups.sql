INSERT INTO public.groups (id, title) VALUES ('1fd242ee-5f45-4f97-aefb-4563e8f1f07e', 'Investors');
INSERT INTO public.groups (id, title) VALUES ('2702f591-821a-4ae2-b408-d1853782290f', 'Coders');
