INSERT INTO public.groups_users_users ("groupsId", "usersId") VALUES ('1fd242ee-5f45-4f97-aefb-4563e8f1f07e', 'c874d638-b3ec-4326-899a-62bb5a8a8d2b');
INSERT INTO public.groups_users_users ("groupsId", "usersId") VALUES ('1fd242ee-5f45-4f97-aefb-4563e8f1f07e', '7807fde2-4e23-4560-8c3d-82cfdadcaadc');
INSERT INTO public.groups_users_users ("groupsId", "usersId") VALUES ('1fd242ee-5f45-4f97-aefb-4563e8f1f07e', 'aa1377de-4af8-4801-9b5f-d5f3962ff6f0');
INSERT INTO public.groups_users_users ("groupsId", "usersId") VALUES ('2702f591-821a-4ae2-b408-d1853782290f', 'c14c7417-f12d-45ff-8172-66aa84f573be');
INSERT INTO public.groups_users_users ("groupsId", "usersId") VALUES ('2702f591-821a-4ae2-b408-d1853782290f', '6f37f1d7-9b26-4ba4-b534-8a2fc22558f3');
