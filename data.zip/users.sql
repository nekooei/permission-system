INSERT INTO public.users (id, name) VALUES ('c14c7417-f12d-45ff-8172-66aa84f573be', 'Milad');
INSERT INTO public.users (id, name) VALUES ('c874d638-b3ec-4326-899a-62bb5a8a8d2b', 'Elon');
INSERT INTO public.users (id, name) VALUES ('7807fde2-4e23-4560-8c3d-82cfdadcaadc', 'Warren');
INSERT INTO public.users (id, name) VALUES ('aa1377de-4af8-4801-9b5f-d5f3962ff6f0', 'Soheil');
INSERT INTO public.users (id, name) VALUES ('6f37f1d7-9b26-4ba4-b534-8a2fc22558f3', 'Sam');
